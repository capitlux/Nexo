const CONST_ServerBaseUrl = 'http://gpx02.gparts.eu:5001';
//const CONST_ServerBaseUrl = 'https://localhost:44380';

//const CONST_WebAppBaseUrl = 'http://localhost:58533/';
const CONST_WebAppBaseUrl = 'http://pesw.gparts.eu';